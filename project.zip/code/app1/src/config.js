const config = {
  url: 'http://localhost:4000',
}

export default config
