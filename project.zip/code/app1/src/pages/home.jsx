import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getAllUsers, deleteUser } from "../services/user";
import { toast } from "react-toastify";

function Home() {
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);
  const role = sessionStorage.getItem("role");
  const token = sessionStorage.getItem("token");

  useEffect(() => {
    const fetchUsers = async () => {
      if (!token) {
        toast.error("You are not authorized. Please login.");
        navigate("/login");
        return;
      }

      const result = await getAllUsers(token);
      if (result.status === "success") {
        setUsers(result.data);
      } else {
        toast.error("Failed to fetch user data");
      }
    };

    fetchUsers();
  }, [token, navigate]);

  const onLogout = () => {
    sessionStorage.removeItem("token");
    sessionStorage.removeItem("name");
    sessionStorage.removeItem("role");
    navigate("/login");
  };

  const handleDelete = async (userId) => {
    if (role !== "Admin") {
      toast.error(
        "Restricted action: You do not have permission to delete records."
      );
      return;
    }

    const result = await deleteUser(token, userId);

    if (result.status === "success") {
      setUsers(users.filter((user) => user.id !== userId));
      toast.success("User deleted successfully");
    } else {
      toast.error(result.message || "Failed to delete user");
    }
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4 text-center">Role-Based Access Control (RBAC)</h2>
      <div className="d-flex justify-content-between mb-3">
        <h4>
          Welcome, {sessionStorage.getItem("name")}, ({role})
        </h4>
        <button onClick={onLogout} className="btn btn-warning">
          Logout
        </button>
      </div>

      {/* Role-based permissions section */}
      <div className="mb-4">
        <h4>Role-Based Permissions</h4>
        <table className="table table-bordered">
          <thead className="table-light">
            <tr>
              <th>Role</th>
              <th>Permissions</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Admin</td>
              <td>Can view, edit, and delete records.</td>
            </tr>
            <tr>
              <td>Manager</td>
              <td>Can view and edit records only.</td>
            </tr>
            <tr>
              <td>User</td>
              <td>Can only view records.</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div className="table-responsive">
        <table className="table table-striped table-bordered">
          <thead className="table-dark">
            <tr>
              <th>ID</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Role</th>
              <th>Edit</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id}>
                <td>{user.id}</td>
                <td>{user.firstName}</td>
                <td>{user.lastName}</td>
                <td>{user.email}</td>
                <td>{user.phoneNumber}</td>
                <td>{user.role}</td>
                <td>
                  <button
                    className="btn btn-primary btn-sm"
                    onClick={() => {
                      const role = sessionStorage.getItem("role");
                      if (role === "User") {
                        toast.error(
                          "Restricted action: You do not have permission to edit records."
                        );
                        return;
                      }

                      navigate(`/edit/${user.id}`, { state: { user } });
                    }}
                  >
                    Edit
                  </button>
                </td>
                <td>
                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => handleDelete(user.id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Home;
