import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { register } from "../services/user";

function RegisterUser() {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [role, setRole] = useState(""); // Added state for role

  const navigate = useNavigate();

  const onCancel = () => {
    navigate("/login");
  };

  const onRegister = async () => {
    if (firstName.length === 0) {
      alert("Enter first name");
    } else if (lastName.length === 0) {
      alert("Enter last name");
    } else if (email.length === 0) {
      alert("Enter email");
    } else if (password.length === 0) {
      alert("Enter password");
    } else if (confirmPassword.length === 0) {
      alert("Confirm password");
    } else if (password !== confirmPassword) {
      alert("Password does not match");
    } else if (role.length === 0) {
      alert("Select a role");
    } else {
      const result = await register(
        firstName,
        lastName,
        email,
        phone,
        password,
        role
      );
      if (result["status"] === "success") {
        alert("Successfully registered a user");
        navigate("/login");
      } else {
        alert("Failed to register the user");
      }
    }
  };

  return (
    <div>
      <h2 className="page-title">Register</h2>

      <div className="row mt-5">
        <div className="col-2"></div>

        <div className="col">
          <div className="row">
            <div className="col">
              <div className="mb-3">
                <label>First Name</label>
                <input
                  onChange={(e) => setFirstName(e.target.value)}
                  type="text"
                  className="form-control"
                />
              </div>
            </div>

            <div className="col">
              <div className="mb-3">
                <label>Last Name</label>
                <input
                  onChange={(e) => setLastName(e.target.value)}
                  type="text"
                  className="form-control"
                />
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col">
              <div className="mb-3">
                <label>Email</label>
                <input
                  onChange={(e) => setEmail(e.target.value)}
                  type="email"
                  className="form-control"
                />
              </div>
            </div>

            <div className="col">
              <div className="mb-3">
                <label>Phone Number</label>
                <input
                  onChange={(e) => setPhone(e.target.value)}
                  type="tel"
                  className="form-control"
                />
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col">
              <div className="mb-3">
                <label>Password</label>
                <input
                  onChange={(e) => setPassword(e.target.value)}
                  type="password"
                  className="form-control"
                />
              </div>
            </div>

            <div className="col">
              <div className="mb-3">
                <label>Confirm Password</label>
                <input
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  type="password"
                  className="form-control"
                />
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col">
              <div className="mb-3">
                <label>Role</label>
                <select
                  onChange={(e) => setRole(e.target.value)}
                  className="form-control"
                  value={role}
                >
                  <option value="">Select Role</option>
                  <option value="Admin">Admin</option>
                  <option value="Manager">Manager</option>
                  <option value="User">User</option>
                </select>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col">
              <div className="mb-3">
                Already have an account? <Link to="/login">Login here</Link>
              </div>

              <button onClick={onRegister} className="btn btn-success">
                Register
              </button>
              <button onClick={onCancel} className="btn btn-danger ms-2">
                Cancel
              </button>
            </div>
          </div>
        </div>

        <div className="col-2"></div>
      </div>
    </div>
  );
}

export default RegisterUser;
