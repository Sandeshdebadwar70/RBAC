import { useLocation, useNavigate } from "react-router-dom";
import { useState } from "react";
import { updateUser } from "../services/user";
import { toast } from "react-toastify";

function EditUserForm() {
  const { state } = useLocation();
  const navigate = useNavigate();
  const [user, setUser] = useState(state.user);
  const token = sessionStorage.getItem("token");

  if (!token) {
    navigate("/login");
  }

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser({ ...user, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const result = await updateUser(token, user);
    if (result.status === "success") {
      toast.success("User updated successfully");
      navigate("/home");
    } else {
      toast.error(result.message || "Failed to update user");
    }
  };

  return (
    <div className="container mt-4">
      <h2>Edit User</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">First Name</label>
          <input
            type="text"
            name="firstName"
            value={user.firstName}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Last Name</label>
          <input
            type="text"
            name="lastName"
            value={user.lastName}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Email</label>
          <input
            type="email"
            name="email"
            value={user.email}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Phone</label>
          <input
            type="text"
            name="phoneNumber"
            value={user.phoneNumber}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Role</label>
          <select
            name="role"
            value={user.role}
            onChange={handleChange}
            className="form-control"
            required
          >
            <option value="Admin">Admin</option>
            <option value="Manager">Manager</option>
            <option value="User">User</option>
          </select>
        </div>
        <button type="submit" className="btn btn-primary">
          Save Changes
        </button>
        <button
          type="button"
          className="btn btn-secondary ms-2"
          onClick={() => navigate("/home")}
        >
          Cancel
        </button>
      </form>
    </div>
  );
}

export default EditUserForm;
